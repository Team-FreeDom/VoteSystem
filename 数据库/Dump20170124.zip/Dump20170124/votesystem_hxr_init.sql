CREATE DATABASE  IF NOT EXISTS `votesystem` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `votesystem`;
-- MySQL dump 10.13  Distrib 5.6.10, for Win64 (x86_64)
--
-- Host: localhost    Database: votesystem
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hxr_init`
--

DROP TABLE IF EXISTS `hxr_init`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hxr_init` (
  `id` int(11) NOT NULL,
  `hxrbh` varchar(45) DEFAULT NULL COMMENT '候选人编号',
  `xm` varchar(45) DEFAULT NULL COMMENT '候选人姓名',
  `szxy` varchar(45) DEFAULT NULL COMMENT '所在学院',
  `jslx` varchar(45) DEFAULT NULL COMMENT '教授类型： 0 专任教授，1 学院领导，2 党政领导',
  `sfqnjs` varchar(45) DEFAULT NULL COMMENT '是否青年教师，1 是青年教师 0 非青年教师',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='候选人初始信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hxr_init`
--

LOCK TABLES `hxr_init` WRITE;
/*!40000 ALTER TABLE `hxr_init` DISABLE KEYS */;
INSERT INTO `hxr_init` VALUES (1,'001','陈斌','动科学院','0','0'),(2,'002','张彬','动科学院','0','0'),(5,'003','王晓清','动科学院','1','0'),(6,'004','贺建华','动科学院','2','0'),(7,'005','余兴龙','动医学院','0','0'),(8,'006','薛立群','动医学院','0','0'),(9,'007','程天印','动医学院','1','0'),(10,'008','孙志良','动医学院','2','0'),(11,'009','吴明亮','工学院','0','1'),(12,'010','王辉','工学院','0','1'),(13,'011','孙松林','工学院','1','0'),(14,'012','贺林波','公法学院','0','1'),(15,'013','李燕凌','公法学院','1','0'),(16,'014','符少辉','公法学院','2','0'),(17,'015','周明星','教育学院','0','0'),(18,'016','邹立君','教育学院','0','0'),(19,'017','周先进','教育学院','1','0'),(20,'018','匡远配','经济学院','0','1'),(21,'019','周孟亮','经济学院','0','1'),(22,'020','李明贤','经济学院','1','0'),(23,'021','曾福生','经济学院','2','0'),(24,'022','王辉宪','理学院','0','0'),(25,'023','李小平','理学院','0','0'),(26,'024','周文新','理学院','1','0'),(27,'025','官春云','农学院','0','0'),(28,'026','邹应斌','农学院','0','0'),(29,'027','黄璜','农学院','0','0'),(30,'028','屠乃美','农学院','0','0'),(31,'029','张海清','农学院','1','0'),(32,'030','周清明','农学院','2','0'),(33,'031','陈光辉','农学院','2','0'),(34,'032','杜红梅','商学院','0','0'),(35,'033','刘文丽','商学院','0','0'),(36,'034','兰勇','商学院','1','1'),(37,'035','肖浪涛','生科学院','0','0'),(38,'036','周冀衡','生科学院','0','0'),(39,'037','彭克勤','生科学院','0','0'),(40,'038','易自力','生科学院','2','0'),(41,'039','卢向阳','生科学院','2','0'),(42,'040','邹冬生','生科学院','2','0'),(43,'041','谭兴和','食科学院','0','0'),(44,'042','蒋立文','食科学院','0','0'),(45,'043','邓放明','食科学院','1','0'),(46,'044','吴卫国','食科学院','1','0'),(47,'045','肖夕君','体艺学院','0','0'),(48,'046','尹建强','体艺学院','0','0'),(49,'047','李骅','体艺学院','1','0'),(50,'048','曾亚平','外语学院','0','0'),(51,'049','胡东平','外语学院','1','0'),(52,'050','戴小鹏','信息学院','0','0'),(53,'051','张红燕','信息学院','0','1'),(54,'052','沈岳','信息学院','1','0'),(55,'053','刘仲华','园艺学院','0','0'),(56,'054','邓子牛','园艺学院','0','0'),(57,'055','刘明月','园艺学院','0','0'),(58,'056','于晓英','园艺学院','0','0'),(59,'057','龙岳林','园艺学院','0','0'),(60,'058','钟晓红','园艺学院','2','0'),(61,'059','廖晓兰','植保学院','0','0'),(62,'060','袁哲明','植保学院','0','1'),(63,'061','李晓刚','植保学院','0','1'),(64,'062','戴良英','植保学院','1','0'),(65,'063','张杨珠','资环学院','0','0'),(66,'064','荣湘民','资环学院','0','0'),(67,'065','关欣','资环学院','0','0'),(68,'066','罗琳','资环学院','1','0'),(69,'067','王健','马克思学院','0','0'),(70,'068','李长泰','马克思学院','0','1'),(71,'069','岳好平','国际学院','1','0');
/*!40000 ALTER TABLE `hxr_init` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-24 10:48:57

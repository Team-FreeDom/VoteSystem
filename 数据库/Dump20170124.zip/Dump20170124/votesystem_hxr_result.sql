CREATE DATABASE  IF NOT EXISTS `votesystem` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `votesystem`;
-- MySQL dump 10.13  Distrib 5.6.10, for Win64 (x86_64)
--
-- Host: localhost    Database: votesystem
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hxr_result`
--

DROP TABLE IF EXISTS `hxr_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hxr_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hxrbh` varchar(45) DEFAULT NULL COMMENT '候选人编号',
  `status` varchar(45) DEFAULT NULL COMMENT '状态： 0，当选；1：待选；2：淘汰',
  `jd` varchar(45) DEFAULT NULL COMMENT '阶段',
  `lc` varchar(45) DEFAULT NULL COMMENT '轮次',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60338 DEFAULT CHARSET=utf8 COMMENT='候选人投票结果表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hxr_result`
--

LOCK TABLES `hxr_result` WRITE;
/*!40000 ALTER TABLE `hxr_result` DISABLE KEYS */;
INSERT INTO `hxr_result` VALUES (60269,'001','是','1','1'),(60270,'002','是','1','1'),(60271,'003','是','1','1'),(60272,'004','是','1','1'),(60273,'005','是','1','1'),(60274,'006','是','1','1'),(60275,'007','是','1','1'),(60276,'008','是','1','1'),(60277,'009','是','1','1'),(60278,'010','是','1','1'),(60279,'011','是','1','1'),(60280,'012','是','1','1'),(60281,'013','是','1','1'),(60282,'014','是','1','1'),(60283,'015','是','1','1'),(60284,'016','是','1','1'),(60285,'017','是','1','1'),(60286,'018','是','1','1'),(60287,'019','是','1','1'),(60288,'020','是','1','1'),(60289,'021','是','1','1'),(60290,'022','是','1','1'),(60291,'023','是','1','1'),(60292,'024','是','2','1'),(60293,'025','否','2','1'),(60294,'026','是','1','1'),(60295,'027','是','1','1'),(60296,'028','是','1','1'),(60297,'029','是','1','1'),(60298,'030','是','1','1'),(60299,'031','否','2','1'),(60300,'032','是','1','1'),(60301,'033','是','1','1'),(60302,'034','是','1','1'),(60303,'035','是','1','1'),(60304,'036','是','1','1'),(60305,'037','是','1','1'),(60306,'038','否','2','1'),(60307,'039','是','1','1'),(60308,'040','是','1','1'),(60309,'041','是','1','1'),(60310,'042','是','1','1'),(60311,'043','是','1','1'),(60312,'044','是','1','1'),(60313,'045','是','1','1'),(60314,'046','是','1','1'),(60315,'047','是','1','1'),(60316,'048','是','1','1'),(60317,'049','是','1','1'),(60318,'050','是','1','1'),(60319,'051','是','1','1'),(60320,'052','是','1','1'),(60321,'053','是','2','1'),(60322,'054','是','1','1'),(60323,'055','否','2','1'),(60324,'056','是','1','1'),(60325,'057','是','1','1'),(60326,'058','是','1','1'),(60327,'059','是','1','1'),(60328,'060','是','1','1'),(60329,'061','是','1','1'),(60330,'062','是','1','1'),(60331,'063','是','1','1'),(60332,'064','是','1','1'),(60333,'065','是','1','1'),(60334,'066','是','1','1'),(60335,'067','是','1','1'),(60336,'068','是','1','1'),(60337,'069','是','1','1');
/*!40000 ALTER TABLE `hxr_result` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-24 10:48:57

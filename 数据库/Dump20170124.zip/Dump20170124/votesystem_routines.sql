CREATE DATABASE  IF NOT EXISTS `votesystem` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `votesystem`;
-- MySQL dump 10.13  Distrib 5.6.10, for Win64 (x86_64)
--
-- Host: localhost    Database: votesystem
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'votesystem'
--
/*!50003 DROP PROCEDURE IF EXISTS `getallrs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getallrs`(out jsrs varchar(4), out xyrs varchar(4), out dzrs varchar(4), out tjrs varchar(4),out tpzrs varchar(4))
BEGIN
 DECLARE x varchar(4);

set @sqlstr=concat('select count(*)  into @x  from hxrxxb    where tgsh=\'','是','\'',' and jslx=\'','0','\''); 

PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
select @x into jsrs;
set @sqlstr=concat('select count(*)  into @x  from hxrxxb  where tgsh=\'','是','\'',' and jslx=\'','1','\'');  
 PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
select @x into xyrs;
set @sqlstr=concat('select count(*)  into @x from hxrxxb  where  tgsh=\'','是','\'',' and jslx=\'','2','\'');  
 PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
select @x into dzrs;
set @sqlstr=concat('select count(*)  into @x  from yhb  where tpzt=\'','1','\'');  
 PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
select @x into tjrs;
set @sqlstr=concat('select count(*)  into @x  from yhb     where sfqx=\'','1','\'');  
 PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
select @x into tpzrs;

insert into temp (hxrbh,ps) values ('getallrs','ok');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd1data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd1data`(in xlc varchar(3))
BEGIN
start TRANSACTION; 
    -- delete  from temp;
	-- update (select hxrbh,count(*) as ps from xswyhpx.tpxxb where tpxxb.jd=jd and tpxxb.lc=lc group by hxrbh) as temp, xswyhpx.hxrxxb  set hxrxxb.ps=temp.ps where temp.hxrbh=hxrxxb.hxrbh and hxrxxb.jd=jd and hxrxxb.lc=lc;
    set  @sqlstr=concat('select xybh,xymc,jbzb,jslx,hxrbh,xm,sfqnjs from xyxxb,hxrxxb where  xyxxb.xymc=hxrxxb.szxybh  and zt=\'','0','\'  and jd=\'','1','\' and lc=\'',xlc,'\' order by (xybh+0),(ps+0) desc');
     PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
-- insert into temp (hxrbh,ps) values ('getjd1data','ok');
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd1gl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd1gl`(in  xjd varchar(3), in xlc varchar(3) )
BEGIN

 SELECT szxybh,jbzb,jslx,
concat('<input class=\'checkboxes\' data-set=\'',jslx,'\' value=\'',hxrbh,'\' type=\'checkbox\'>') as hxrbh,
			case when (sfqnjs= '1') then concat(xm,'(青)') 
						else   xm 
            end  as xm , 
             case when  (ps>140) then concat(' <span class=\'badge\'>',ps,'</span>')  
			          else   concat(' <span class=\'badge bg_blue\'>',ps,'</span>')   
             end as ps 
FROM xswyhpx.hxrxxb
left join xyxxb
on  hxrxxb.szxybh = xyxxb.xymc
WHERE jd=xjd and lc=xlc  and zt='0' order by szxybh, ps desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd1khd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd1khd`( in  xjd varchar (3), in xlc varchar(3) )
BEGIN
SELECT szxybh,jbzb,jslx,
concat('<input class=\'checkboxes\' data-set=\'',jslx+1,'\' value=\'',hxrbh,'\' type=\'checkbox\'>') as hxrbh,
			case when (sfqnjs= '1') then concat(xm,'(青)') 
						else   xm 
            end  as xm 
             
FROM xswyhpx.hxrxxb
left join xyxxb
on  hxrxxb.szxybh = xyxxb.xymc
WHERE jd=xjd and lc=xlc  and zt='0'  order by szxybh;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd1nextdata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd1nextdata`( in xlc varchar(30) , out updateok int )
BEGIN
 -- set @sqlstr=concat('update hxrxxb set zt =\'','88','\' where tgsh<>\'','是','\'',' and zt=\'','0','\'',' and jd=\'','1','\'','  and lc=',xlc-1,'\'');
update hxrxxb set zt ='88' where tgsh<>'是'  and zt='0'  and jd='1'  and lc=xlc-1;

 -- select @sqlstr;
-- PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	-- execute stmtPrepared;
	-- deallocate prepare stmtPrepared; 
 -- set @sqlstr=concat('UPDATE hxrxxb set zt=\'','0','\'' ,' , lc=\'' ,xlc,'\' ,ps=\'','0','\' where tgsh<>\'','是','\'',' and zt=\'','99','\'  and jd=\'','1','\' and lc=',xlc-1,'\'');
  UPDATE hxrxxb set zt=0, lc=xlc, ps=0 where tgsh<>'是' and zt='99'  and jd='1' and lc=xlc-1; 
-- select @sqlstr;
-- PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	-- execute stmtPrepared;
	-- deallocate prepare stmtPrepared; 
-- set @sqlstr=concat('select * from hxrxxb where zt=\'','0','\'',' and jd=\'','1','\'',' and lc=\'',xlc,'\'','  and tgsh<>\'','是','\' order by szxybh, (ps+0)');

-- select * from hxrxxb where zt='0','\'',' and jd=\'','1','\'',' and lc=\'',xlc,'\'','  and tgsh<>\'','是','\' order by szxybh, (ps+0)');select @sqlstr;
-- PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	-- execute stmtPrepared;
	--  deallocate prepare stmtPrepared; 
   select * from hxrxxb where zt='0' and jd='1' and lc=xlc and tgsh<>'是' order by szxybh, (ps+0);
  select 1 into  updateok;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd2data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd2data`( in var char(3) , out getok int)
BEGIN
-- start TRANSACTION; 
    -- delete  from temp;
	-- update (select hxrbh,count(*) as ps from xswyhpx.tpxxb where tpxxb.jd=jd and tpxxb.lc=lc group by hxrbh) as temp, xswyhpx.hxrxxb  set hxrxxb.ps=temp.ps where temp.hxrbh=hxrxxb.hxrbh and hxrxxb.jd=jd and hxrxxb.lc=lc;

 set  @sqlstr=concat('update hxrxxb  set ps=\'','0','\' , jd=\'','2','\' , lc=\'','1','\'  , zt=\'','0','\' where    tgsh<>\'','是','\'');
     PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	deallocate prepare stmtPrepared; 
    set  @sqlstr=concat('select xybh,xymc,jslx,hxrbh,xm,sfqnjs from xyxxb,hxrxxb where  xyxxb.xymc=hxrxxb.szxybh  and tgsh<>\'','是','\' and jd=\'','2','\' and lc=\'','1','\' order by (xybh+0),(ps+0) desc');
      pREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
    	 deallocate prepare stmtPrepared; 
     COMMIT;
select 1 into getok;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd2gl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd2gl`(in  xjd varchar (3), in xlc varchar(3) )
BEGIN
SELECT hxrbh,szxybh,
       case when (jslx= '0') then '专任教授'
			 when (jslx= '1') then '学院领导'
			else   '校职能部门领导'
            end  as jslx ,
			case when (sfqnjs= '1') then concat(xm,'(青)') 
						else   xm 
            end  as xm ,
           case when  (ps>140) then concat(' <span class=\'badge \'>',ps,'</span>')  
			          else   concat(' <span class=\'badge bg_blue \'>',ps,'</span>')   
             end as ps 
             
FROM xswyhpx.hxrxxb
left join xyxxb
on  hxrxxb.szxybh = xyxxb.xymc
WHERE jd=xjd and lc=xlc  and zt='0'  order by ps desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd2khd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd2khd`(in  xjd varchar (3), in xlc varchar(3) )
BEGIN
SELECT szxybh,jbzb,jslx,
concat('<input class=\'checkboxes\' data-set=\'',jslx,'\' value=\'',hxrbh,'\' type=\'checkbox\'>') as hxrbh,
			case when (sfqnjs= '1') then concat(xm,'(青)') 
						else   xm 
            end  as xm 
             
FROM xswyhpx.hxrxxb
left join xyxxb
on  hxrxxb.szxybh = xyxxb.xymc
WHERE jd=xjd and lc=xlc  and zt='0' order by szxybh;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getjd2nextdata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `getjd2nextdata`( in xlc varchar(3) ,out getok int )
BEGIN

 set @sqlstr=concat('update hxrxxb set zt =\'','88','\' where tgsh<>\'','是','\'',' and zt=\'','0','\'',' and jd=\'','2','\'','  and lc=',xlc-1);

 select @sqlstr;
PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	execute stmtPrepared;
	deallocate prepare stmtPrepared; 
 set @sqlstr=concat('UPDATE hxrxxb set zt=\'','0','\'' ,' , lc=\'' ,xlc,'\' ,ps=\'','0','\' where tgsh<>\'','是','\'',' and zt=\'','99','\'  and jd=\'','2','\' and lc=',xlc-1);
PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	execute stmtPrepared;
	deallocate prepare stmtPrepared; 
    set @sqlstr=concat('select * from hxrxxb where zt=\'','0','\'',' and jd=\'','2','\'',' and lc=\'',xlc,'\'','  and tgsh<>\'','是','\' order by  szxybh, (ps+0)');
   PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	execute stmtPrepared;
	deallocate prepare stmtPrepared;
select 1 into  getok;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `init` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `init`(out  initok int)
BEGIN
start transaction;
	-- update xswyhpx.xtkz set jd='1',lc='1',xtzt='1',zyxrs='57',zrjsrs='29',xdrs='28',dzldrs='14';
	delete  from xswyhpx.tpxxb ;
	update xswyhpx.yhb set tpzt='0',sfqx='0';
	update xswyhpx.xyxxb set jbzb='2';
	update xswyhpx.xyxxb set jbzb='1' where xymc='国际学院' ;
	update xswyhpx.xyxxb set jbzb='1' where xymc='马克思学院' ;
	delete from hxrxxb;
	insert into xswyhpx.hxrxxb (hxrbh,xm,szxybh,zt,ps,jslx,sfqnjs,tgsh,byxx,jd,lc ) select hxrbh,xm,szxybh,zt,ps,jslx,sfqnjs,tgsh,byxx,jd,lc from  xswyhpx.hxrjbbback; 
	update xswyhpx.hxrxxb set jd='1',lc='1',zt='0',ps='0',tgsh='否';
	commit;
	select 1 into initok;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inserttpxxb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `inserttpxxb`(in jd varchar(3),in lc varchar(3),in tpyh varchar(17),in hxrbh text, out insok  int)
BEGIN
-- 插入一个投票用户tpyh所投的所有候选人hxr
    set @sqlStr = CONCAT('delete from xswyhpx.tpxxb  where jd=\'',jd,'\' and  lc=\'',lc,'\' and tpyh=\'',tpyh,'\'');

		select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;

		set @sqlStr = CONCAT('insert into xswyhpx.tpxxb(tpyh,hxrbh,jd,lc) values (\'',tpyh,'\',','\'',hxrbh,'\',','\'',jd,'\',\'',lc,'\')');

		 select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;
select 1 into insok;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `parseVoteInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`127.0.0.1` PROCEDURE `parseVoteInfo`(in strText text, out tprsCnt int )
BEGIN 
	declare i int unsigned ; -- 循环变量，用作下标，以便顺序遍历字符串中的每个字符
	declare textLen int unsigned; -- 总字符串的长度
	declare jd varchar(100); -- 投票阶段
	declare lc varchar(100); -- 投票轮次
	declare tpyh varchar(100); -- 投票用户名
	declare hxrbhs varchar(3000); -- 候选人的集合
	declare ch varchar(100); -- 用来每次接收一个字符
	declare k int unsigned; -- 循环计数变量，用来计数区别前面3个字段：阶段、轮次和投票人编号。
	declare tmpStr varchar(3000); -- 临时变量

	set textLen=char_length(strText); -- 注意，此处最好不用length()函数：因为length()函数返回字符串的字节数，而非字符个数。
	set i=1; -- MySQL中的第一个字符下标为1

	start transaction; -- 事务开始
	while i<=textLen do     
		set k=1;
		while k<=3 do  -- 第1、2、3次循环分别解析出：阶段、轮次、投票人。
			set ch=substring(strText,i,1);
			set tmpStr=''; 
			
			-- 将读到逗号之前的文本截取到变量tmpStr中。
			while ch <>',' and i<=textLen do 
				set tmpStr=concat(tmpStr,ch);
				set i=i+1;
				set ch=substring(strText,i,1);
			end while;
			 
			case k   
			when 1 then set jd=tmpStr;  -- 当前解析得到了”投票阶段“信息
			when 2 then set lc=tmpStr;  -- 当前解析得到了”投票轮次“信息
			when 3 then set tpyh=tmpStr;-- 当前解析得到了”投票用户“信息，即投票人
			end case;
			set k=k+1;
			set i=i+1;
		end while;
		
		set ch=substring(strText,i,1); -- 读走当前位置的逗号”,“
		set tmpStr='';

		-- 读取每条记录中前3个字段之后至字段分隔符或者字符结尾处之间的字符
        -- 此处的信息为被投票人的信息，形式如'001','002','003'
		while ch <>'|' and i<=textLen do
			set tmpStr=concat(tmpStr,ch);
			set i=i+1;
			set ch=substring(strText,i,1);
		end while;
		set hxrbhs=tmpStr;     -- 得到被投票人的信息 

		--  以下语句操作数据库：拼装sql语句字符串，组成一条prepare语句，再执行。
		
		-- 为了防止同一个人重复投票，首先删除该投票人所投的所有票。
		set @sqlStr = CONCAT('delete from tpxxb where  tpyh =\'',tpyh
						,'\'  and jd=\'',jd,'\' and lc=\'',lc,'\'');
		-- select @sqlStr; -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;
		
		-- 插入一个投票用户tpyh所投的所有候选人hxr
		set @sqlStr = CONCAT('insert into xswyhpx.tpxxb(tpyh,hxrbh,hxrszxy,hxrlx,jd,lc) select \'',
						tpyh ,'\' as tpyh,hxrxxb.hxrbh, szxybh,jslx,', jd,' as jd, ',lc,
						' as lc  from hxrxxb  where  hxrbh in (',hxrbhs,')  and jd=\'',jd,'\' and lc=\'',lc,'\'');

		-- select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;

		set i=i+1;
	end while;
	commit; -- 事务结束
	
	-- 查询投票信息表tpxxb，统计该投票人的投票的人数
	set @sqlStr = CONCAT('select count(distinct tpyh)   into @tprs from tpxxb');
	-- select @sqlStr;  -- 输出构造的SQL，供调试用
	PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	execute stmtPrepared;
	deallocate prepare stmtPrepared; 

	select @tprs into tprsCnt;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updatehxrzt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `updatehxrzt`( in strText text, out updateok int )
BEGIN
   
	 declare i int unsigned ; -- 循环变量，用作下标，以便顺序遍历字符串中的每个字符
	declare textLen int unsigned; -- 总字符串的长度
	declare jd varchar(100); -- 投票阶段
	declare lc varchar(100); -- 投票轮次
	declare tpyh varchar(100); -- 投票用户名
	declare hxrbhs varchar(3000); -- 候选人的集合
	declare ch varchar(100); -- 用来每次接收一个字符
	declare k int unsigned; -- 循环计数变量，用来计数区别前面3个字段：阶段、轮次和投票人编号。
	declare tmpStr varchar(3000); -- 临时变量

	set textLen=char_length(strText); -- 注意，此处最好不用length()函数：因为length()函数返回字符串的字节数，而非字符个数。
	set i=1; -- MySQL中的第一个字符下标为1

	start transaction; -- 事务开始
	while i<=textLen do     
		set k=1;
		while k<=2 do  -- 第1、2次循环分别解析出：阶段、轮次。
			set ch=substring(strText,i,1);
			set tmpStr=''; 
			
			-- 将读到逗号之前的文本截取到变量tmpStr中。
			while ch <>',' and i<=textLen do 
				set tmpStr=concat(tmpStr,ch);
				set i=i+1;
				set ch=substring(strText,i,1);
			end while;
			 
			case k   
			when 1 then set jd=tmpStr;  -- 当前解析得到了”投票阶段“信息
			when 2 then set lc=tmpStr;  -- 当前解析得到了”投票轮次“信息
			end case;
			set k=k+1;
			set i=i+1;
		end while;
		
		set ch=substring(strText,i,1); -- 读走当前位置的逗号”,“
		set tmpStr='';

		-- 读取每条记录中前3个字段之后至字段分隔符或者字符结尾处之间的字符
        -- 此处的信息为被投票人的信息，形式如'001','002','003'
		while ch <>'|' and i<=textLen do
			set tmpStr=concat(tmpStr,ch);
			set i=i+1;
			set ch=substring(strText,i,1);
		end while;
		set hxrbhs=tmpStr;     -- 得到被投票人的信息 

		--  以下语句操作数据库：拼装sql语句字符串，组成一条prepare语句，再执行。
			
		-- 更新入选人的状态为"99"，候选人
		set @sqlStr = CONCAT('update   xswyhpx.hxrxxb set zt=\'','99', '\' where   hxrbh in (',hxrbhs,')  and jd=\'',jd,'\' and lc=\'',lc,'\'');

		select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;

		set i=i+1;
	end while;
	commit; -- 事务结束
   
    select 1 into updateok;
	 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateps` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `updateps`( in jd varchar(3), in lc varchar(3), in hxrbh varchar(10), in  ps int  )
BEGIN
   
	start TRANSACTION; 
    -- delete  from temp;
	-- update (select hxrbh,count(*) as ps from xswyhpx.tpxxb where tpxxb.jd=jd and tpxxb.lc=lc group by hxrbh) as temp, xswyhpx.hxrxxb  set hxrxxb.ps=temp.ps where temp.hxrbh=hxrxxb.hxrbh and hxrxxb.jd=jd and hxrxxb.lc=lc;
    set  @sqlstr=concat('update hxrxxb set ps=',ps,' where jd=\'',jd,'\' and lc=\'',lc,'\' and hxrbh=\'',hxrbh,'\'');
     PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
	   execute stmtPrepared;
	deallocate prepare stmtPrepared; 
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updaterxrzt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`pxmis`@`%` PROCEDURE `updaterxrzt`( in strText text,  out updateok varchar(3)   )
BEGIN
   
	 declare i int unsigned ; -- 循环变量，用作下标，以便顺序遍历字符串中的每个字符
	declare textLen int unsigned; -- 总字符串的长度
	declare xjd varchar(100); -- 投票阶段
	declare xlc varchar(100); -- 投票轮次
	declare tpyh varchar(100); -- 投票用户名
	declare hxrbhs varchar(3000); -- 候选人的集合
	declare ch varchar(100); -- 用来每次接收一个字符
	declare k int unsigned; -- 循环计数变量，用来计数区别前面3个字段：阶段、轮次和投票人编号。
	declare tmpStr varchar(3000); -- 临时变量

	set textLen=char_length(strText); -- 注意，此处最好不用length()函数：因为length()函数返回字符串的字节数，而非字符个数。
	set i=1; -- MySQL中的第一个字符下标为1

	start transaction; -- 事务开始
	while i<=textLen do     
		set k=1;
		while k<=2 do  -- 第1、2次循环分别解析出：阶段、轮次。
			set ch=substring(strText,i,1);
			set tmpStr=''; 
			
			-- 将读到逗号之前的文本截取到变量tmpStr中。
			while ch <>',' and i<=textLen do 
				set tmpStr=concat(tmpStr,ch);
				set i=i+1;
				set ch=substring(strText,i,1);
			end while;
			 
			case k   
			when 1 then set xjd=tmpStr;  -- 当前解析得到了”投票阶段“信息
			when 2 then set xlc=tmpStr;  -- 当前解析得到了”投票轮次“信息
			end case;
			set k=k+1;
			set i=i+1;
		end while;
		
		set ch=substring(strText,i,1); -- 读走当前位置的逗号”,“
		set tmpStr='';

		-- 读取每条记录中前3个字段之后至字段分隔符或者字符结尾处之间的字符
        -- 此处的信息为被投票人的信息，形式如'001','002','003'
		while ch <>'|' and i<=textLen do
			set tmpStr=concat(tmpStr,ch);
			set i=i+1;
			set ch=substring(strText,i,1);
		end while;
		set hxrbhs=tmpStr;     -- 得到被投票人的信息 

		--  以下语句操作数据库：拼装sql语句字符串，组成一条prepare语句，再执行。
			
		-- 更新用入选人的状态，候选人
		set @sqlStr = CONCAT('update   xswyhpx.hxrxxb set tgsh=\'','是', '\', zt=\'','1', '\'  where   hxrbh in (',hxrbhs,')  and jd=\'',xjd,'\' and lc=\'',xlc,'\'');

		-- select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		 execute stmtPrepared;
		 deallocate prepare stmtPrepared;
-- 修改学院指标
      -- update   xswyhpx.hxrxxb set tgsh='是', zt='1'  where   hxrbh in ( hxrbhs  )  and jd=xjd and lc=xlc;

		set i=i+1;
	end while;
         -- delete from temp;
        -- insert temp select szxybh, count(*)  as ps  from hxrxxb where tgsh='是'   and  hxrbh in ( hxrbhs ) and  jd=xjd and lc=xlc group by szxybh; 
               
      -- update xyxxb ,hxrxxb  set jbzb=jbzb-temp.ps where xybh=
        set @sqlStr = CONCAT('update  (select szxybh, count(*)  as X  from hxrxxb where tgsh=\'','是','\'   and  hxrbh in (',hxrbhs,') and  jd=\'',xjd,'\' and lc=\'',xlc,'\' group by szxybh ) as temp , xswyhpx.xyxxb  set  xyxxb.jbzb= xyxxb.jbzb-temp.x where xyxxb.xymc=temp.szxybh ');

		-- select @sqlStr;  -- 输出构造的SQL，供调试用
		PREPARE stmtPrepared FROM @sqlStr; -- prepare 必须采用这种传参方式
		execute stmtPrepared;
		deallocate prepare stmtPrepared;

	commit; -- 事务结束
   
    select '1' into updateok;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-24 10:48:58
